// funcion display de menus

// fin funcion display menus

// creamos array de personas


// Evento click nuevo usuario/cliente

// Evento click buscar usuario/cliente

// Evento click borrar usuario/cliente


// funcion nuevo usuario y control evento

// fin funcion nuevo usuario

// funcion buscar usuario

//fin funcion buscar usuario

// función borrar usuario lupa

// fin funcion borrar usuario lupa

// funcion borrar usuario submit

// fin funcion borrar usuario submit

// flecha volver al menu

// fin flecha volver al menú principal